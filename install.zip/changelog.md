## v1.2
- Updated hosts file
- Added more info to ``README.md``
---
## v1.3
- Added a new hosts list provider [hosts](https://github.com/StevenBlack/hosts)
- Updated hosts file with current