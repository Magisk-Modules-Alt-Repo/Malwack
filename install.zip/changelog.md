## v1.2
- Updated hosts file
- Added more info to ``README.md``