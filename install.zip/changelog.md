## v5.0.0
- Auto update every 24 hours applies after reboot
- Added service.sh to setup cron
- Added logging
- Updated hosts file
- Removed added commands using built-in BusyBox

## v4.2.8
- Updated hosts file

## v4.2.7
- Updated hosts file

## v4.2.6
- Updated hosts file

## v4.2.5
- Updated hosts file

## v4.2.4
- Updated hosts file

## v4.2.3
- Updated hosts file

## v4.2.2
- Updated hosts file
## v4.2.1
- Fixed the help command adding the ``whitelist`` command on it.
## v4.2
- Updated Hosts file and added a new hosts link
---
## v4.1
- Update Hosts File
- Fixed changelog
---
## v4.0
- Updated Hosts file
- Updated readme.md
- Added Sed and MV commands with rw perms
- Added a new command that allows users to whitelist domains.
---
## v3.0
- Added curl command as some users do not have it installed on their phones
- Fixed the malwack command to get hosts file and to block porn as curl was not working for some users.
- Updated Hosts file
---
## v2.6
- Update Hosts file
---
## v2.5
- Update Hosts file
---
## v2.4
- Update Hosts File
---
## v2.3
- Update Hosts fle
---
## v2.2
- Update Hosts File
---
## v2.1
- update hosts file
---
## v2.0 - Major Update
- Added terminal commands
- use ``malwack --help`` for all available commands
- Updated README.md
- Updated hosts life
---
## v1.4
- Updated hosts file
- added custom header to hosts file 
---
## v1.3
- Added a new hosts list provider [hosts](https://github.com/StevenBlack/hosts)
- Updated hosts file with current
---
## v1.2
- Updated hosts file
- Added more info to ``README.md``